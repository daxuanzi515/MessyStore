import time
from launch import LaunchDescription
from launch.actions import ExecuteProcess, RegisterEventHandler, TimerAction
from launch.event_handlers import OnProcessExit, OnProcessStart

def generate_launch_description():
    # 定义路径

    time_stamp = time.strftime("%Y%m%d_%H%M%S")
    test_images = "/home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/Test_dataset/test_images"
    test_bag = "/home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/Test_dataset/test_bags.bag"
    detection_bag = f"/home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/Test_dataset/detection_result_{time_stamp}.bag"
    workspace_setup_script = "/home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/install/setup.bash"

    # Part 1: 执行 build.sh 脚本
    build_and_source = ExecuteProcess(
        cmd=[
            'xterm', '-e', 
            f"bash -c 'chmod +x /home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/build.sh && /home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/build.sh'"
        ],
        shell=True
    )

    # Part 2: 转换图片到 bag 文件并播放（保持在同一终端）
    convert_and_play_bag = ExecuteProcess(
        cmd=[
            'xterm', '-hold', '-e', 
            f"bash -c 'source {workspace_setup_script} && "
            # f"(timeout 1s ros2 run culane_to_bag convert {test_images} {test_bag}); "  # 使用子 shell控制超时
            f"ros2 bag play {test_bag} --topic /detection_target'"
        ],
        shell=True
    )

    # Part 3: 启动检测节点并记录检测结果
    run_detection_and_record_bag = ExecuteProcess(
        cmd=[
            'xterm', '-hold', '-e', 
            f"bash -c 'source {workspace_setup_script} && "
            f"ros2 run lane_detection_starter_cpp mydetector & "
            f"ros2 bag record -o {detection_bag} /detection_result'"
        ],
        shell=True
    )

    return LaunchDescription([
        build_and_source,
        # 当 build.sh 完成后，执行转换和播放
        RegisterEventHandler(
            OnProcessExit(
                target_action=build_and_source,
                on_exit=[
                    TimerAction(period=0.0, actions=[convert_and_play_bag])  # 执行转换并播放 bag
                ]
            )
        ),
        # 当播放 bag 文件开始后，启动检测节点并记录 bag
        RegisterEventHandler(
            OnProcessStart(
                target_action=convert_and_play_bag,
                on_start=[run_detection_and_record_bag]
            )
        )
    ])
