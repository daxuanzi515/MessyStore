#include <chrono>
#include <functional>
#include <memory>
#include <vector>
#include <cstdint>
#include <opencv2/opencv.hpp>
#include "rclcpp/rclcpp.hpp"
#include "rclcpp/qos.hpp"

#ifdef ROS_DISTRO_JAZZ
#include "cv_bridge/cv_bridge.hpp"
#else
#include "cv_bridge/cv_bridge.h"
#endif
#include "lane_detection_msgs/msg/detection_target.hpp"
#include "lane_detection_msgs/msg/detection_result.hpp"
#include "lane_detection_msgs/msg/lane.hpp"
#include "sensor_msgs/msg/image.hpp"

using std::placeholders::_1;
using namespace std::chrono_literals;

class Detector : public rclcpp::Node
{
public:
  Detector() : Node("detector")
  {
    RCLCPP_INFO(this->get_logger(), "Detector node has been started");

    result_pub_ = this->create_publisher<lane_detection_msgs::msg::DetectionResult>(
    "/detection_result", rclcpp::QoS(10));

    detected_img_pub_ = this->create_publisher<sensor_msgs::msg::Image>(
    "/detected_image", rclcpp::QoS(10));

    target_sub_ = this->create_subscription<lane_detection_msgs::msg::DetectionTarget>(
    "/detection_target", rclcpp::QoS(10), std::bind(&Detector::target_callback, this, _1));

  }

private:
  void target_callback(const lane_detection_msgs::msg::DetectionTarget::SharedPtr msg)
  {
    RCLCPP_INFO(this->get_logger(), "Received detection target with frame_id %d", msg->frame_id);

    auto start_time = std::chrono::high_resolution_clock::now();

    lane_detection_msgs::msg::DetectionResult detection_result;
    detection_result.header = msg->header;
    detection_result.frame_id = msg->frame_id;
    detection_result.gt_lanes = msg->gt_lanes;

    cv_bridge::CvImagePtr cv_ptr;
    try {
        cv_ptr = cv_bridge::toCvCopy(msg->image_raw, sensor_msgs::image_encodings::BGR8);
    } catch (cv_bridge::Exception& e) {
        RCLCPP_ERROR(this->get_logger(), "cv_bridge exception: %s", e.what());
        return;
    }

    // 动态生成唯一的文件名（根据 frame_id 或者时间戳）
    std::string frame_id_str = std::to_string(msg->frame_id);
    std::string timestamp_str = std::to_string(this->get_clock()->now().nanoseconds());

    // 文件保存路径前缀
    std::string base_path = "/home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/Test_dataset/detected_images/";
    // 执行车道检测
    auto detected_lanes = lane_detection(cv_ptr->image);

    // 构建检测结果
    for (const auto& lane : detected_lanes) {
        lane_detection_msgs::msg::Lane lane_msg;
        lane_msg.coordinates.assign(lane.begin(), lane.end());
        detection_result.lanes.push_back(lane_msg);
    }

    auto end_time = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time);
    detection_result.run_time = duration.count();

    RCLCPP_INFO(this->get_logger(), "Detected %zu lanes with run time %.2f ms", 
                detected_lanes.size(), detection_result.run_time);

    std::vector<std::vector<uint32_t>> gt_lanes;
    for (const auto& lane : msg->gt_lanes) {
        gt_lanes.push_back(lane.coordinates);
    }

    // 阶段2：边缘检测并保存
    cv::Mat canny_edges = canny_edge_detection(cv_ptr->image);
    std::string canny_filename = base_path + "canny_edges_" + frame_id_str + "_" + timestamp_str + ".jpg";
    // cv::imshow("Canny Edge Detection", canny_edges);
    // cv::waitKey(1);  // 确保图像显示
    cv::imwrite(canny_filename, canny_edges);  // 动态保存边缘检测图像

    // 绘制车道线
    draw_lanes(cv_ptr->image, detected_lanes, gt_lanes);
    // 阶段3：显示绘制车道后的图像并保存
    std::string lanes_filename = base_path + "detected_lanes_" + frame_id_str + "_" + timestamp_str + ".jpg";
    // cv::imshow("Detected Lanes", cv_ptr->image);
    // cv::waitKey(1);  // 确保图像显示
    cv::imwrite(lanes_filename, cv_ptr->image);  // 动态保存车道线图像
    // 发布结果
    result_pub_->publish(detection_result);
    detected_img_pub_->publish(*(cv_ptr->toImageMsg()));
  }

    cv::Mat canny_edge_detection(const cv::Mat& img_cv)
    {
        cv::Mat gray, blur, canny;

        // 转换为灰度图
        cv::cvtColor(img_cv, gray, cv::COLOR_BGR2GRAY);

        // 应用双边滤波以减少噪声并保持边缘
        cv::bilateralFilter(gray, blur, 9, 75, 75);

        // 自适应阈值计算
        double median = cv::mean(blur)[0]; // 使用中值作为亮度的衡量
        double lower = std::max(0.0, 0.7 * median); // 设置较低的阈值
        double upper = std::min(255.0, 1.3 * median); // 设置较高的阈值

        // 使用Sobel滤波增强边缘
        cv::Mat sobelX, sobelY;
        cv::Sobel(blur, sobelX, CV_64F, 1, 0, 3);  // 水平梯度
        cv::Sobel(blur, sobelY, CV_64F, 0, 1, 3);  // 垂直梯度

        cv::Mat sobel = abs(sobelX) + abs(sobelY);
        cv::Mat sobel_8u;
        cv::convertScaleAbs(sobel, sobel_8u);

        // 应用Canny边缘检测
        cv::Canny(sobel_8u, canny, lower, upper, 3, true);

        return canny;
    }

    cv::Mat region_of_interest(const cv::Mat& canny)
    {
        cv::Mat mask = cv::Mat::zeros(canny.size(), canny.type());

        // 使用一个六边形的感兴趣区域，可以根据图片手动调整顶点坐标
        cv::Point pts[1][6];
        
        // 定义多边形的顶点，调整使其适应不同道路场景
        pts[0][0] = cv::Point(50, canny.rows);           // 左下角
        pts[0][1] = cv::Point(canny.cols - 50, canny.rows); // 右下角
        pts[0][2] = cv::Point(canny.cols - 200, canny.rows / 2); // 右中间
        pts[0][3] = cv::Point(canny.cols - 600, 300);     // 顶部中间靠右
        pts[0][4] = cv::Point(600, 300);                 // 顶部中间靠左
        pts[0][5] = cv::Point(200, canny.rows / 2);      // 左中间

        const cv::Point* ppt[1] = {pts[0]};
        int npt[] = {6};

        // 填充多边形区域
        cv::fillPoly(mask, ppt, npt, 1, cv::Scalar(255, 255, 255), cv::LINE_8);
        cv::Mat masked_image;
        cv::bitwise_and(canny, mask, masked_image);

        return masked_image;
    }



    std::vector<std::vector<uint32_t>> lane_detection(const cv::Mat& img_cv)
    {
        cv::Mat canny = canny_edge_detection(img_cv);
        cv::Mat cropped_image = region_of_interest(canny);

        std::vector<cv::Vec4i> lines;
        cv::HoughLinesP(cropped_image, lines, 1, CV_PI / 180, 110, 30, 10); // Lower threshold and minLineLength
        
        std::vector<std::vector<uint32_t>> return_lines;
        for (const auto& line : lines)
        {
            return_lines.push_back({line[0], line[1], line[2], line[3]});
        }
        return return_lines;
    }

    void draw_lanes(cv::Mat& img_cv, const std::vector<std::vector<uint32_t>>& lanes, const std::vector<std::vector<uint32_t>>& gt_lanes)
    {
        for (const auto& lane : lanes)
        {
            for (size_t i = 0; i < lane.size(); i += 2)
            {
                if (i + 1 < lane.size())
                {
                    int x = lane[i];
                    int y = lane[i + 1];
                    cv::circle(img_cv, cv::Point(x, y), 5, cv::Scalar(0, 0, 255), -1);
                }
            }
        }

        for (const auto& lane : gt_lanes)
        {
            for (size_t i = 0; i < lane.size(); i += 2)
            {
                if (i + 1 < lane.size())
                {
                    int x = lane[i];
                    int y = lane[i + 1];
                    cv::circle(img_cv, cv::Point(x, y), 5, cv::Scalar(0, 255, 0), -1);
                }
            }
        }
    }

  rclcpp::Publisher<lane_detection_msgs::msg::DetectionResult>::SharedPtr result_pub_;
  rclcpp::Subscription<lane_detection_msgs::msg::DetectionTarget>::SharedPtr target_sub_;
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr detected_img_pub_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<Detector>());
  rclcpp::shutdown();
  return 0;
}