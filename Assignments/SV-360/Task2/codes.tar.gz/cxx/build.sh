#!/bin/bash
# 构建三个包
colcon build --packages-select culane_to_bag --allow-overriding culane_to_bag
colcon build --packages-select lane_detection_msgs --allow-overriding lane_detection_msgs
colcon build --packages-select lane_detection_starter_cpp --allow-overriding lane_detection_starter_cpp

# 构建完成后，source 环境
source /home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/install/setup.bash

ros2 run culane_to_bag convert /home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/Test_dataset/test_images /home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/Test_dataset/test_bags.bag

exit 0
