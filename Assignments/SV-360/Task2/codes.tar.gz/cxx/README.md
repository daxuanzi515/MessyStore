# README

## Environment & Requirements

- Ubuntu 22.04
- ROS2 humble version
- `python` >= 3.10.1
- `numpy` == 1.21.2
- `opencv-python` == 4.10.0.84
- `VSCode`

Install Commands:

```bash
sudo apt-get install libopencv-core-dev libopencv-highgui-dev libopencv-imgproc-dev
sudo apt-get install ros-humble-cv-bridge
```

```bash
pip install numpy==1.21.2
pip install opencv-python==4.10.0.84
```

## Change your workspace structure

Root folder: `/home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/`

Test_dataset folder: (need create) 

- `/detected_images`: `canny_edge_XXX.jpg`, `detected_lanes_XXX.jpg`
- `/test_images`: `XXX.jpg`, `XXX.lines.txt`
- `detection_result.bag`
- `test_bags.bag`

build.sh (copy)

## Launch script

Launcher:

```bash
cd /home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/

colcon build --packages-select lane_detection_starter_cpp

source install/setup.bash

ros2 launch lane_detection_starter_cpp lane_detection_launch.py
```

## Commands

If above launcher fails, follow next steps:

Open a new terminal A to build packages and load workspace:

```bash
cd /home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/

colcon build --packages-select culane_to_bag --allow-overriding culane_to_bag
colcon build --packages-select lane_detection_msgs --allow-overriding lane_detection_msgs
colcon build --packages-select lane_detection_starter_cpp --allow-overriding lane_detection_starter_cpp

source install/setup.bash
```

Open a new terminal B to convert `test_bags.bag `, and `Ctrl+C`  to stop terminal:

```bash
ros2 run culane_to_bag convert /home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/Test_dataset/test_images /home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/Test_dataset/test_bags.bag
```

Open a new terminal C:

```bash
ros2 run lane_detection_starter_cpp mydetector & ros2 bag record /detection_result -o /home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/Test_dataset/detection_result.bag
```

Return to terminal B, enter command:

```bash
ros2 bag play /home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/Test_dataset/test_bags.bag --topic /detection_target 
```

When terminal C is blocked, `Ctrl + C` to stop terminal C.

Then return to terminal A, enter command to check record bag:

```bash
ros2 bag info /home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/Test_dataset/detection_result.bag
```

## Check Results

Go to `Test_dataset` and check:

`detected_images`, `detection_result.bag`