# 使用说明

这是一个将culane数据集转换为ros2 bag的工具，主要用于culane数据集的训练和测试。

## 1. 安装依赖

```bash
pip install -r requirements.txt
```

## 2. 编译

```bash
colcon build --packages-select culane_to_bag
```
colcon build --packages-select lane_detection_starter_cpp
colcon build --packages-select lane_detection_msgs

## 3. 运行转换脚本

```bash
source install/setup.bash
ros2 run culane_to_bag convert /path/to/culane/dataset /path/to/output.bag
```

ros2 run culane_to_bag convert /home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/Test_dataset/test_images /home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/Test_dataset/test_bags.bag

ros2 run lane_detection_starter_cpp detector

ros2 run lane_detection_starter_cpp mydetector & ros2 bag record /detection_result -o /home/cxx/SMART_VEHICLES/Detect_Vehicle_Lanes/templates/cxx/Test_dataset/detection_result.bag



output your md to pdf:
pandoc README.md -o output.pdf --pdf-engine=wkhtmltopdf --pdf-engine-opt=--enable-local-file-access


